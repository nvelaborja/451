﻿namespace Business_Analyst
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.listBoxZipDem = new System.Windows.Forms.ListBox();
            this.listBoxCityDem = new System.Windows.Forms.ListBox();
            this.boxStateDem = new System.Windows.Forms.ComboBox();
            this.labelZip = new System.Windows.Forms.Label();
            this.labelCity = new System.Windows.Forms.Label();
            this.labelState = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.buttonAddCategoryDem = new System.Windows.Forms.Button();
            this.listBoxCategoryDem = new System.Windows.Forms.ListBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listBoxSearchResultsZip = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxZip = new System.Windows.Forms.TextBox();
            this.textBoxRatingZip = new System.Windows.Forms.TextBox();
            this.textBoxReviewsZip = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.buttonRemoveCategoryDem = new System.Windows.Forms.Button();
            this.listBoxSelectedCategoriesDem = new System.Windows.Forms.ListBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label65 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox24State = new System.Windows.Forms.TextBox();
            this.textBox44State = new System.Windows.Forms.TextBox();
            this.textBox65State = new System.Windows.Forms.TextBox();
            this.textBox64State = new System.Windows.Forms.TextBox();
            this.textBox18State = new System.Windows.Forms.TextBox();
            this.labelPercent = new System.Windows.Forms.Label();
            this.labelAge = new System.Windows.Forms.Label();
            this.textBoxAgeState = new System.Windows.Forms.TextBox();
            this.labelMedAge = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBoxIncomeState = new System.Windows.Forms.TextBox();
            this.textBoxPopState = new System.Windows.Forms.TextBox();
            this.labelIncome = new System.Windows.Forms.Label();
            this.labelPop = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox24City = new System.Windows.Forms.TextBox();
            this.textBox44City = new System.Windows.Forms.TextBox();
            this.textBox65City = new System.Windows.Forms.TextBox();
            this.textBox64City = new System.Windows.Forms.TextBox();
            this.textBox18City = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxAgeCity = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.textBoxIncomeCity = new System.Windows.Forms.TextBox();
            this.textBoxPopCity = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox24Zip = new System.Windows.Forms.TextBox();
            this.textBox44Zip = new System.Windows.Forms.TextBox();
            this.textBox65Zip = new System.Windows.Forms.TextBox();
            this.textBox64Zip = new System.Windows.Forms.TextBox();
            this.textBox18Zip = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.textBoxAgeZip = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.textBoxIncomeZip = new System.Windows.Forms.TextBox();
            this.textBoxPopZip = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label26 = new System.Windows.Forms.Label();
            this.listBoxSearchResultsCity = new System.Windows.Forms.ListBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBoxCity = new System.Windows.Forms.TextBox();
            this.textBoxRatingCity = new System.Windows.Forms.TextBox();
            this.textBoxReviewsCity = new System.Windows.Forms.TextBox();
            this.groupBox21 = new System.Windows.Forms.GroupBox();
            this.groupBox22 = new System.Windows.Forms.GroupBox();
            this.label29 = new System.Windows.Forms.Label();
            this.listBoxSearchResultsState = new System.Windows.Forms.ListBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.textBoxState = new System.Windows.Forms.TextBox();
            this.textBoxRatingState = new System.Windows.Forms.TextBox();
            this.textBoxReviewsState = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox31 = new System.Windows.Forms.GroupBox();
            this.reviewGrid = new System.Windows.Forms.DataGridView();
            this.Stars = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Review = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox30 = new System.Windows.Forms.GroupBox();
            this.buttonClear = new System.Windows.Forms.Button();
            this.buttonSearch = new System.Windows.Forms.Button();
            this.resultsGrid = new System.Windows.Forms.DataGridView();
            this.groupBox29 = new System.Windows.Forms.GroupBox();
            this.numericMaxReviews = new System.Windows.Forms.NumericUpDown();
            this.numericMinReviews = new System.Windows.Forms.NumericUpDown();
            this.numericMaxRating = new System.Windows.Forms.NumericUpDown();
            this.numericMinRating = new System.Windows.Forms.NumericUpDown();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox28 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.listBoxSelectedAttributes = new System.Windows.Forms.ListBox();
            this.groupBox27 = new System.Windows.Forms.GroupBox();
            this.buttonAddAttribute = new System.Windows.Forms.Button();
            this.boxValue = new System.Windows.Forms.ComboBox();
            this.groupBox25 = new System.Windows.Forms.GroupBox();
            this.listBoxAttributes = new System.Windows.Forms.ListBox();
            this.groupBox23 = new System.Windows.Forms.GroupBox();
            this.listBoxZipSearch = new System.Windows.Forms.ListBox();
            this.listBoxCitySearch = new System.Windows.Forms.ListBox();
            this.boxStateSearch = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox24 = new System.Windows.Forms.GroupBox();
            this.buttonAddSearch = new System.Windows.Forms.Button();
            this.listBoxCategorySearch = new System.Windows.Forms.ListBox();
            this.groupBox26 = new System.Windows.Forms.GroupBox();
            this.buttonRemoveSearch = new System.Windows.Forms.Button();
            this.listBoxSelectedCategoriesSearch = new System.Windows.Forms.ListBox();
            this.BusinessName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.City = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.State = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Zipcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Rating = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NumReviews = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox21.SuspendLayout();
            this.groupBox22.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox31.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reviewGrid)).BeginInit();
            this.groupBox30.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultsGrid)).BeginInit();
            this.groupBox29.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericMaxReviews)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinReviews)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMaxRating)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinRating)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox28.SuspendLayout();
            this.groupBox27.SuspendLayout();
            this.groupBox25.SuspendLayout();
            this.groupBox23.SuspendLayout();
            this.groupBox24.SuspendLayout();
            this.groupBox26.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox1.Controls.Add(this.listBoxZipDem);
            this.groupBox1.Controls.Add(this.listBoxCityDem);
            this.groupBox1.Controls.Add(this.boxStateDem);
            this.groupBox1.Controls.Add(this.labelZip);
            this.groupBox1.Controls.Add(this.labelCity);
            this.groupBox1.Controls.Add(this.labelState);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox1.Location = new System.Drawing.Point(3, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(356, 483);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select Business Location";
            // 
            // listBoxZipDem
            // 
            this.listBoxZipDem.BackColor = System.Drawing.Color.Gray;
            this.listBoxZipDem.Cursor = System.Windows.Forms.Cursors.Default;
            this.listBoxZipDem.ForeColor = System.Drawing.Color.White;
            this.listBoxZipDem.FormattingEnabled = true;
            this.listBoxZipDem.Location = new System.Drawing.Point(96, 314);
            this.listBoxZipDem.Name = "listBoxZipDem";
            this.listBoxZipDem.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBoxZipDem.ScrollAlwaysVisible = true;
            this.listBoxZipDem.Size = new System.Drawing.Size(249, 147);
            this.listBoxZipDem.TabIndex = 4;
            this.listBoxZipDem.SelectedValueChanged += new System.EventHandler(this.listBoxZip_SelectedValueChanged);
            // 
            // listBoxCityDem
            // 
            this.listBoxCityDem.BackColor = System.Drawing.Color.Gray;
            this.listBoxCityDem.Cursor = System.Windows.Forms.Cursors.Default;
            this.listBoxCityDem.ForeColor = System.Drawing.Color.White;
            this.listBoxCityDem.FormattingEnabled = true;
            this.listBoxCityDem.Location = new System.Drawing.Point(96, 84);
            this.listBoxCityDem.Name = "listBoxCityDem";
            this.listBoxCityDem.ScrollAlwaysVisible = true;
            this.listBoxCityDem.Size = new System.Drawing.Size(249, 212);
            this.listBoxCityDem.TabIndex = 2;
            this.listBoxCityDem.SelectedValueChanged += new System.EventHandler(this.listBoxCity_SelectedValueChanged);
            // 
            // boxStateDem
            // 
            this.boxStateDem.BackColor = System.Drawing.Color.Gray;
            this.boxStateDem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boxStateDem.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.boxStateDem.ForeColor = System.Drawing.Color.White;
            this.boxStateDem.FormattingEnabled = true;
            this.boxStateDem.Location = new System.Drawing.Point(96, 43);
            this.boxStateDem.Name = "boxStateDem";
            this.boxStateDem.Size = new System.Drawing.Size(249, 21);
            this.boxStateDem.TabIndex = 3;
            this.boxStateDem.DropDown += new System.EventHandler(this.boxState_DropDown);
            this.boxStateDem.SelectionChangeCommitted += new System.EventHandler(this.boxState_SelectionChangeCommitted);
            // 
            // labelZip
            // 
            this.labelZip.AutoSize = true;
            this.labelZip.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelZip.Location = new System.Drawing.Point(21, 314);
            this.labelZip.Name = "labelZip";
            this.labelZip.Size = new System.Drawing.Size(65, 16);
            this.labelZip.TabIndex = 2;
            this.labelZip.Text = "Zipcode";
            // 
            // labelCity
            // 
            this.labelCity.AutoSize = true;
            this.labelCity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelCity.Location = new System.Drawing.Point(21, 84);
            this.labelCity.Name = "labelCity";
            this.labelCity.Size = new System.Drawing.Size(34, 16);
            this.labelCity.TabIndex = 1;
            this.labelCity.Text = "City";
            // 
            // labelState
            // 
            this.labelState.AutoSize = true;
            this.labelState.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelState.Location = new System.Drawing.Point(21, 44);
            this.labelState.Name = "labelState";
            this.labelState.Size = new System.Drawing.Size(44, 16);
            this.labelState.TabIndex = 0;
            this.labelState.Text = "State";
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox5.Controls.Add(this.buttonAddCategoryDem);
            this.groupBox5.Controls.Add(this.listBoxCategoryDem);
            this.groupBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox5.Location = new System.Drawing.Point(3, 495);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(356, 254);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Select Business Category";
            // 
            // buttonAddCategoryDem
            // 
            this.buttonAddCategoryDem.BackColor = System.Drawing.Color.Silver;
            this.buttonAddCategoryDem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddCategoryDem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonAddCategoryDem.Location = new System.Drawing.Point(18, 214);
            this.buttonAddCategoryDem.Name = "buttonAddCategoryDem";
            this.buttonAddCategoryDem.Size = new System.Drawing.Size(317, 28);
            this.buttonAddCategoryDem.TabIndex = 1;
            this.buttonAddCategoryDem.Text = "ADD";
            this.buttonAddCategoryDem.UseVisualStyleBackColor = false;
            this.buttonAddCategoryDem.Click += new System.EventHandler(this.buttonAddCategory_Click);
            // 
            // listBoxCategoryDem
            // 
            this.listBoxCategoryDem.BackColor = System.Drawing.Color.Gray;
            this.listBoxCategoryDem.ForeColor = System.Drawing.Color.White;
            this.listBoxCategoryDem.FormattingEnabled = true;
            this.listBoxCategoryDem.Location = new System.Drawing.Point(7, 19);
            this.listBoxCategoryDem.Name = "listBoxCategoryDem";
            this.listBoxCategoryDem.ScrollAlwaysVisible = true;
            this.listBoxCategoryDem.Size = new System.Drawing.Size(338, 186);
            this.listBoxCategoryDem.TabIndex = 0;
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.Gray;
            this.groupBox7.Controls.Add(this.label1);
            this.groupBox7.Controls.Add(this.listBoxSearchResultsZip);
            this.groupBox7.Controls.Add(this.label2);
            this.groupBox7.Controls.Add(this.label3);
            this.groupBox7.Controls.Add(this.textBoxZip);
            this.groupBox7.Controls.Add(this.textBoxRatingZip);
            this.groupBox7.Controls.Add(this.textBoxReviewsZip);
            this.groupBox7.ForeColor = System.Drawing.Color.White;
            this.groupBox7.Location = new System.Drawing.Point(20, 19);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(327, 444);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Search Results";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 400);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 16);
            this.label1.TabIndex = 19;
            this.label1.Text = "# of Reviews";
            // 
            // listBoxSearchResultsZip
            // 
            this.listBoxSearchResultsZip.BackColor = System.Drawing.Color.Silver;
            this.listBoxSearchResultsZip.ForeColor = System.Drawing.Color.Black;
            this.listBoxSearchResultsZip.FormattingEnabled = true;
            this.listBoxSearchResultsZip.Location = new System.Drawing.Point(7, 20);
            this.listBoxSearchResultsZip.Name = "listBoxSearchResultsZip";
            this.listBoxSearchResultsZip.ScrollAlwaysVisible = true;
            this.listBoxSearchResultsZip.Size = new System.Drawing.Size(314, 290);
            this.listBoxSearchResultsZip.TabIndex = 0;
            this.listBoxSearchResultsZip.SelectedValueChanged += new System.EventHandler(this.listBoxSearchResults_SelectedValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(31, 369);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Rating";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 338);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Zipcode";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxZip
            // 
            this.textBoxZip.BackColor = System.Drawing.Color.Silver;
            this.textBoxZip.ForeColor = System.Drawing.Color.Black;
            this.textBoxZip.Location = new System.Drawing.Point(113, 335);
            this.textBoxZip.Name = "textBoxZip";
            this.textBoxZip.ReadOnly = true;
            this.textBoxZip.Size = new System.Drawing.Size(193, 20);
            this.textBoxZip.TabIndex = 14;
            this.textBoxZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxRatingZip
            // 
            this.textBoxRatingZip.BackColor = System.Drawing.Color.Silver;
            this.textBoxRatingZip.ForeColor = System.Drawing.Color.Black;
            this.textBoxRatingZip.Location = new System.Drawing.Point(113, 366);
            this.textBoxRatingZip.Name = "textBoxRatingZip";
            this.textBoxRatingZip.ReadOnly = true;
            this.textBoxRatingZip.Size = new System.Drawing.Size(193, 20);
            this.textBoxRatingZip.TabIndex = 16;
            this.textBoxRatingZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxReviewsZip
            // 
            this.textBoxReviewsZip.BackColor = System.Drawing.Color.Silver;
            this.textBoxReviewsZip.ForeColor = System.Drawing.Color.Black;
            this.textBoxReviewsZip.Location = new System.Drawing.Point(113, 397);
            this.textBoxReviewsZip.Name = "textBoxReviewsZip";
            this.textBoxReviewsZip.ReadOnly = true;
            this.textBoxReviewsZip.Size = new System.Drawing.Size(193, 20);
            this.textBoxReviewsZip.TabIndex = 15;
            this.textBoxReviewsZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox8.Controls.Add(this.buttonRemoveCategoryDem);
            this.groupBox8.Controls.Add(this.listBoxSelectedCategoriesDem);
            this.groupBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox8.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox8.Location = new System.Drawing.Point(3, 755);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(356, 217);
            this.groupBox8.TabIndex = 5;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Selected Categories";
            // 
            // buttonRemoveCategoryDem
            // 
            this.buttonRemoveCategoryDem.BackColor = System.Drawing.Color.Silver;
            this.buttonRemoveCategoryDem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonRemoveCategoryDem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonRemoveCategoryDem.Location = new System.Drawing.Point(18, 175);
            this.buttonRemoveCategoryDem.Name = "buttonRemoveCategoryDem";
            this.buttonRemoveCategoryDem.Size = new System.Drawing.Size(317, 28);
            this.buttonRemoveCategoryDem.TabIndex = 2;
            this.buttonRemoveCategoryDem.Text = "REMOVE";
            this.buttonRemoveCategoryDem.UseVisualStyleBackColor = false;
            this.buttonRemoveCategoryDem.Click += new System.EventHandler(this.buttonRemoveCategory_Click);
            // 
            // listBoxSelectedCategoriesDem
            // 
            this.listBoxSelectedCategoriesDem.BackColor = System.Drawing.Color.Gray;
            this.listBoxSelectedCategoriesDem.ForeColor = System.Drawing.Color.White;
            this.listBoxSelectedCategoriesDem.FormattingEnabled = true;
            this.listBoxSelectedCategoriesDem.Location = new System.Drawing.Point(6, 19);
            this.listBoxSelectedCategoriesDem.Name = "listBoxSelectedCategoriesDem";
            this.listBoxSelectedCategoriesDem.ScrollAlwaysVisible = true;
            this.listBoxSelectedCategoriesDem.Size = new System.Drawing.Size(339, 147);
            this.listBoxSelectedCategoriesDem.TabIndex = 2;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox9.Controls.Add(this.groupBox2);
            this.groupBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox9.ForeColor = System.Drawing.Color.White;
            this.groupBox9.Location = new System.Drawing.Point(371, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(363, 483);
            this.groupBox9.TabIndex = 6;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "STATE";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Gray;
            this.groupBox2.Controls.Add(this.groupBox4);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox2.ForeColor = System.Drawing.Color.White;
            this.groupBox2.Location = new System.Drawing.Point(21, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(318, 442);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Demographics Summary";
            // 
            // groupBox4
            // 
            this.groupBox4.BackColor = System.Drawing.Color.Silver;
            this.groupBox4.Controls.Add(this.label65);
            this.groupBox4.Controls.Add(this.label64);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.label24);
            this.groupBox4.Controls.Add(this.label18);
            this.groupBox4.Controls.Add(this.textBox24State);
            this.groupBox4.Controls.Add(this.textBox44State);
            this.groupBox4.Controls.Add(this.textBox65State);
            this.groupBox4.Controls.Add(this.textBox64State);
            this.groupBox4.Controls.Add(this.textBox18State);
            this.groupBox4.Controls.Add(this.labelPercent);
            this.groupBox4.Controls.Add(this.labelAge);
            this.groupBox4.Controls.Add(this.textBoxAgeState);
            this.groupBox4.Controls.Add(this.labelMedAge);
            this.groupBox4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox4.Location = new System.Drawing.Point(6, 149);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(306, 280);
            this.groupBox4.TabIndex = 1;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Age Distribution";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(41, 188);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(80, 16);
            this.label65.TabIndex = 13;
            this.label65.Text = "65 and Over";
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(55, 157);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(53, 16);
            this.label64.TabIndex = 12;
            this.label64.Text = "45 to 64";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(55, 126);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(53, 16);
            this.label44.TabIndex = 11;
            this.label44.Text = "25 to 44";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(55, 95);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(53, 16);
            this.label24.TabIndex = 10;
            this.label24.Text = "18 to 24";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(50, 64);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(62, 16);
            this.label18.TabIndex = 9;
            this.label18.Text = "Under 18";
            // 
            // textBox24State
            // 
            this.textBox24State.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox24State.ForeColor = System.Drawing.Color.Black;
            this.textBox24State.Location = new System.Drawing.Point(157, 92);
            this.textBox24State.Name = "textBox24State";
            this.textBox24State.ReadOnly = true;
            this.textBox24State.Size = new System.Drawing.Size(102, 22);
            this.textBox24State.TabIndex = 8;
            this.textBox24State.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox44State
            // 
            this.textBox44State.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox44State.ForeColor = System.Drawing.Color.Black;
            this.textBox44State.Location = new System.Drawing.Point(157, 123);
            this.textBox44State.Name = "textBox44State";
            this.textBox44State.ReadOnly = true;
            this.textBox44State.Size = new System.Drawing.Size(102, 22);
            this.textBox44State.TabIndex = 7;
            this.textBox44State.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox65State
            // 
            this.textBox65State.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox65State.ForeColor = System.Drawing.Color.Black;
            this.textBox65State.Location = new System.Drawing.Point(157, 185);
            this.textBox65State.Name = "textBox65State";
            this.textBox65State.ReadOnly = true;
            this.textBox65State.Size = new System.Drawing.Size(102, 22);
            this.textBox65State.TabIndex = 6;
            this.textBox65State.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox64State
            // 
            this.textBox64State.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox64State.ForeColor = System.Drawing.Color.Black;
            this.textBox64State.Location = new System.Drawing.Point(157, 154);
            this.textBox64State.Name = "textBox64State";
            this.textBox64State.ReadOnly = true;
            this.textBox64State.Size = new System.Drawing.Size(102, 22);
            this.textBox64State.TabIndex = 5;
            this.textBox64State.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18State
            // 
            this.textBox18State.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox18State.ForeColor = System.Drawing.Color.Black;
            this.textBox18State.Location = new System.Drawing.Point(157, 61);
            this.textBox18State.Name = "textBox18State";
            this.textBox18State.ReadOnly = true;
            this.textBox18State.Size = new System.Drawing.Size(102, 22);
            this.textBox18State.TabIndex = 4;
            this.textBox18State.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelPercent
            // 
            this.labelPercent.AutoSize = true;
            this.labelPercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPercent.Location = new System.Drawing.Point(164, 29);
            this.labelPercent.Name = "labelPercent";
            this.labelPercent.Size = new System.Drawing.Size(88, 16);
            this.labelPercent.TabIndex = 3;
            this.labelPercent.Text = "Percentage";
            // 
            // labelAge
            // 
            this.labelAge.AutoSize = true;
            this.labelAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAge.Location = new System.Drawing.Point(63, 29);
            this.labelAge.Name = "labelAge";
            this.labelAge.Size = new System.Drawing.Size(36, 16);
            this.labelAge.TabIndex = 2;
            this.labelAge.Text = "Age";
            // 
            // textBoxAgeState
            // 
            this.textBoxAgeState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxAgeState.ForeColor = System.Drawing.Color.Black;
            this.textBoxAgeState.Location = new System.Drawing.Point(107, 230);
            this.textBoxAgeState.Name = "textBoxAgeState";
            this.textBoxAgeState.ReadOnly = true;
            this.textBoxAgeState.Size = new System.Drawing.Size(193, 22);
            this.textBoxAgeState.TabIndex = 1;
            this.textBoxAgeState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelMedAge
            // 
            this.labelMedAge.AutoSize = true;
            this.labelMedAge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelMedAge.Location = new System.Drawing.Point(8, 231);
            this.labelMedAge.Name = "labelMedAge";
            this.labelMedAge.Size = new System.Drawing.Size(91, 16);
            this.labelMedAge.TabIndex = 0;
            this.labelMedAge.Text = "Median Age";
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Silver;
            this.groupBox3.Controls.Add(this.textBoxIncomeState);
            this.groupBox3.Controls.Add(this.textBoxPopState);
            this.groupBox3.Controls.Add(this.labelIncome);
            this.groupBox3.Controls.Add(this.labelPop);
            this.groupBox3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox3.Location = new System.Drawing.Point(6, 24);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(306, 113);
            this.groupBox3.TabIndex = 0;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Zipcode Demographics";
            // 
            // textBoxIncomeState
            // 
            this.textBoxIncomeState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxIncomeState.ForeColor = System.Drawing.Color.Black;
            this.textBoxIncomeState.Location = new System.Drawing.Point(107, 74);
            this.textBoxIncomeState.Name = "textBoxIncomeState";
            this.textBoxIncomeState.ReadOnly = true;
            this.textBoxIncomeState.Size = new System.Drawing.Size(193, 20);
            this.textBoxIncomeState.TabIndex = 3;
            this.textBoxIncomeState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPopState
            // 
            this.textBoxPopState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxPopState.ForeColor = System.Drawing.Color.Black;
            this.textBoxPopState.Location = new System.Drawing.Point(107, 28);
            this.textBoxPopState.Name = "textBoxPopState";
            this.textBoxPopState.ReadOnly = true;
            this.textBoxPopState.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBoxPopState.Size = new System.Drawing.Size(193, 20);
            this.textBoxPopState.TabIndex = 2;
            this.textBoxPopState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // labelIncome
            // 
            this.labelIncome.AutoSize = true;
            this.labelIncome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIncome.Location = new System.Drawing.Point(6, 75);
            this.labelIncome.Name = "labelIncome";
            this.labelIncome.Size = new System.Drawing.Size(93, 16);
            this.labelIncome.TabIndex = 1;
            this.labelIncome.Text = "Avg. Income";
            // 
            // labelPop
            // 
            this.labelPop.AutoSize = true;
            this.labelPop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPop.Location = new System.Drawing.Point(6, 29);
            this.labelPop.Name = "labelPop";
            this.labelPop.Size = new System.Drawing.Size(82, 16);
            this.labelPop.TabIndex = 0;
            this.labelPop.Text = "Population";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox10.Controls.Add(this.groupBox11);
            this.groupBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox10.ForeColor = System.Drawing.Color.White;
            this.groupBox10.Location = new System.Drawing.Point(740, 6);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(363, 483);
            this.groupBox10.TabIndex = 7;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "CITY";
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.Gray;
            this.groupBox11.Controls.Add(this.groupBox12);
            this.groupBox11.Controls.Add(this.groupBox13);
            this.groupBox11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox11.ForeColor = System.Drawing.Color.White;
            this.groupBox11.Location = new System.Drawing.Point(21, 19);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(318, 442);
            this.groupBox11.TabIndex = 1;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Demographics Summary";
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.Silver;
            this.groupBox12.Controls.Add(this.label4);
            this.groupBox12.Controls.Add(this.label5);
            this.groupBox12.Controls.Add(this.label6);
            this.groupBox12.Controls.Add(this.label7);
            this.groupBox12.Controls.Add(this.label8);
            this.groupBox12.Controls.Add(this.textBox24City);
            this.groupBox12.Controls.Add(this.textBox44City);
            this.groupBox12.Controls.Add(this.textBox65City);
            this.groupBox12.Controls.Add(this.textBox64City);
            this.groupBox12.Controls.Add(this.textBox18City);
            this.groupBox12.Controls.Add(this.label9);
            this.groupBox12.Controls.Add(this.label10);
            this.groupBox12.Controls.Add(this.textBoxAgeCity);
            this.groupBox12.Controls.Add(this.label11);
            this.groupBox12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox12.Location = new System.Drawing.Point(6, 149);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(306, 280);
            this.groupBox12.TabIndex = 1;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Age Distribution";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(41, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 16);
            this.label4.TabIndex = 13;
            this.label4.Text = "65 and Over";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(55, 157);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "45 to 64";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(55, 126);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 16);
            this.label6.TabIndex = 11;
            this.label6.Text = "25 to 44";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(55, 95);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 16);
            this.label7.TabIndex = 10;
            this.label7.Text = "18 to 24";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(50, 64);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(62, 16);
            this.label8.TabIndex = 9;
            this.label8.Text = "Under 18";
            // 
            // textBox24City
            // 
            this.textBox24City.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox24City.ForeColor = System.Drawing.Color.Black;
            this.textBox24City.Location = new System.Drawing.Point(157, 92);
            this.textBox24City.Name = "textBox24City";
            this.textBox24City.ReadOnly = true;
            this.textBox24City.Size = new System.Drawing.Size(102, 22);
            this.textBox24City.TabIndex = 8;
            this.textBox24City.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox44City
            // 
            this.textBox44City.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox44City.ForeColor = System.Drawing.Color.Black;
            this.textBox44City.Location = new System.Drawing.Point(157, 123);
            this.textBox44City.Name = "textBox44City";
            this.textBox44City.ReadOnly = true;
            this.textBox44City.Size = new System.Drawing.Size(102, 22);
            this.textBox44City.TabIndex = 7;
            this.textBox44City.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox65City
            // 
            this.textBox65City.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox65City.ForeColor = System.Drawing.Color.Black;
            this.textBox65City.Location = new System.Drawing.Point(157, 185);
            this.textBox65City.Name = "textBox65City";
            this.textBox65City.ReadOnly = true;
            this.textBox65City.Size = new System.Drawing.Size(102, 22);
            this.textBox65City.TabIndex = 6;
            this.textBox65City.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox64City
            // 
            this.textBox64City.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox64City.ForeColor = System.Drawing.Color.Black;
            this.textBox64City.Location = new System.Drawing.Point(157, 154);
            this.textBox64City.Name = "textBox64City";
            this.textBox64City.ReadOnly = true;
            this.textBox64City.Size = new System.Drawing.Size(102, 22);
            this.textBox64City.TabIndex = 5;
            this.textBox64City.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18City
            // 
            this.textBox18City.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox18City.ForeColor = System.Drawing.Color.Black;
            this.textBox18City.Location = new System.Drawing.Point(157, 61);
            this.textBox18City.Name = "textBox18City";
            this.textBox18City.ReadOnly = true;
            this.textBox18City.Size = new System.Drawing.Size(102, 22);
            this.textBox18City.TabIndex = 4;
            this.textBox18City.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(164, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 16);
            this.label9.TabIndex = 3;
            this.label9.Text = "Percentage";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(63, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(36, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Age";
            // 
            // textBoxAgeCity
            // 
            this.textBoxAgeCity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxAgeCity.ForeColor = System.Drawing.Color.Black;
            this.textBoxAgeCity.Location = new System.Drawing.Point(107, 230);
            this.textBoxAgeCity.Name = "textBoxAgeCity";
            this.textBoxAgeCity.ReadOnly = true;
            this.textBoxAgeCity.Size = new System.Drawing.Size(193, 22);
            this.textBoxAgeCity.TabIndex = 1;
            this.textBoxAgeCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(8, 231);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "Median Age";
            // 
            // groupBox13
            // 
            this.groupBox13.BackColor = System.Drawing.Color.Silver;
            this.groupBox13.Controls.Add(this.textBoxIncomeCity);
            this.groupBox13.Controls.Add(this.textBoxPopCity);
            this.groupBox13.Controls.Add(this.label12);
            this.groupBox13.Controls.Add(this.label13);
            this.groupBox13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox13.Location = new System.Drawing.Point(6, 24);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(306, 113);
            this.groupBox13.TabIndex = 0;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Zipcode Demographics";
            // 
            // textBoxIncomeCity
            // 
            this.textBoxIncomeCity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxIncomeCity.ForeColor = System.Drawing.Color.Black;
            this.textBoxIncomeCity.Location = new System.Drawing.Point(107, 74);
            this.textBoxIncomeCity.Name = "textBoxIncomeCity";
            this.textBoxIncomeCity.ReadOnly = true;
            this.textBoxIncomeCity.Size = new System.Drawing.Size(193, 20);
            this.textBoxIncomeCity.TabIndex = 3;
            this.textBoxIncomeCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPopCity
            // 
            this.textBoxPopCity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxPopCity.ForeColor = System.Drawing.Color.Black;
            this.textBoxPopCity.Location = new System.Drawing.Point(107, 28);
            this.textBoxPopCity.Name = "textBoxPopCity";
            this.textBoxPopCity.ReadOnly = true;
            this.textBoxPopCity.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBoxPopCity.Size = new System.Drawing.Size(193, 20);
            this.textBoxPopCity.TabIndex = 2;
            this.textBoxPopCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 75);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(93, 16);
            this.label12.TabIndex = 1;
            this.label12.Text = "Avg. Income";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(6, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 16);
            this.label13.TabIndex = 0;
            this.label13.Text = "Population";
            // 
            // groupBox14
            // 
            this.groupBox14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox14.Controls.Add(this.groupBox15);
            this.groupBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox14.ForeColor = System.Drawing.Color.White;
            this.groupBox14.Location = new System.Drawing.Point(1109, 6);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(363, 483);
            this.groupBox14.TabIndex = 8;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "ZIPCODE";
            // 
            // groupBox15
            // 
            this.groupBox15.BackColor = System.Drawing.Color.Gray;
            this.groupBox15.Controls.Add(this.groupBox16);
            this.groupBox15.Controls.Add(this.groupBox17);
            this.groupBox15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox15.ForeColor = System.Drawing.Color.White;
            this.groupBox15.Location = new System.Drawing.Point(21, 19);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(318, 442);
            this.groupBox15.TabIndex = 1;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Demographics Summary";
            // 
            // groupBox16
            // 
            this.groupBox16.BackColor = System.Drawing.Color.Silver;
            this.groupBox16.Controls.Add(this.label14);
            this.groupBox16.Controls.Add(this.label15);
            this.groupBox16.Controls.Add(this.label16);
            this.groupBox16.Controls.Add(this.label17);
            this.groupBox16.Controls.Add(this.label19);
            this.groupBox16.Controls.Add(this.textBox24Zip);
            this.groupBox16.Controls.Add(this.textBox44Zip);
            this.groupBox16.Controls.Add(this.textBox65Zip);
            this.groupBox16.Controls.Add(this.textBox64Zip);
            this.groupBox16.Controls.Add(this.textBox18Zip);
            this.groupBox16.Controls.Add(this.label20);
            this.groupBox16.Controls.Add(this.label21);
            this.groupBox16.Controls.Add(this.textBoxAgeZip);
            this.groupBox16.Controls.Add(this.label22);
            this.groupBox16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox16.Location = new System.Drawing.Point(6, 149);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(306, 280);
            this.groupBox16.TabIndex = 1;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Age Distribution";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(41, 188);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(80, 16);
            this.label14.TabIndex = 13;
            this.label14.Text = "65 and Over";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(55, 157);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 16);
            this.label15.TabIndex = 12;
            this.label15.Text = "45 to 64";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(55, 126);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 16);
            this.label16.TabIndex = 11;
            this.label16.Text = "25 to 44";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(55, 95);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 16);
            this.label17.TabIndex = 10;
            this.label17.Text = "18 to 24";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(50, 64);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(62, 16);
            this.label19.TabIndex = 9;
            this.label19.Text = "Under 18";
            // 
            // textBox24Zip
            // 
            this.textBox24Zip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox24Zip.ForeColor = System.Drawing.Color.Black;
            this.textBox24Zip.Location = new System.Drawing.Point(157, 92);
            this.textBox24Zip.Name = "textBox24Zip";
            this.textBox24Zip.ReadOnly = true;
            this.textBox24Zip.Size = new System.Drawing.Size(102, 22);
            this.textBox24Zip.TabIndex = 8;
            this.textBox24Zip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox44Zip
            // 
            this.textBox44Zip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox44Zip.ForeColor = System.Drawing.Color.Black;
            this.textBox44Zip.Location = new System.Drawing.Point(157, 123);
            this.textBox44Zip.Name = "textBox44Zip";
            this.textBox44Zip.ReadOnly = true;
            this.textBox44Zip.Size = new System.Drawing.Size(102, 22);
            this.textBox44Zip.TabIndex = 7;
            this.textBox44Zip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox65Zip
            // 
            this.textBox65Zip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox65Zip.ForeColor = System.Drawing.Color.Black;
            this.textBox65Zip.Location = new System.Drawing.Point(157, 185);
            this.textBox65Zip.Name = "textBox65Zip";
            this.textBox65Zip.ReadOnly = true;
            this.textBox65Zip.Size = new System.Drawing.Size(102, 22);
            this.textBox65Zip.TabIndex = 6;
            this.textBox65Zip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox64Zip
            // 
            this.textBox64Zip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox64Zip.ForeColor = System.Drawing.Color.Black;
            this.textBox64Zip.Location = new System.Drawing.Point(157, 154);
            this.textBox64Zip.Name = "textBox64Zip";
            this.textBox64Zip.ReadOnly = true;
            this.textBox64Zip.Size = new System.Drawing.Size(102, 22);
            this.textBox64Zip.TabIndex = 5;
            this.textBox64Zip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18Zip
            // 
            this.textBox18Zip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBox18Zip.ForeColor = System.Drawing.Color.Black;
            this.textBox18Zip.Location = new System.Drawing.Point(157, 61);
            this.textBox18Zip.Name = "textBox18Zip";
            this.textBox18Zip.ReadOnly = true;
            this.textBox18Zip.Size = new System.Drawing.Size(102, 22);
            this.textBox18Zip.TabIndex = 4;
            this.textBox18Zip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(164, 29);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(88, 16);
            this.label20.TabIndex = 3;
            this.label20.Text = "Percentage";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(63, 29);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(36, 16);
            this.label21.TabIndex = 2;
            this.label21.Text = "Age";
            // 
            // textBoxAgeZip
            // 
            this.textBoxAgeZip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxAgeZip.ForeColor = System.Drawing.Color.Black;
            this.textBoxAgeZip.Location = new System.Drawing.Point(107, 230);
            this.textBoxAgeZip.Name = "textBoxAgeZip";
            this.textBoxAgeZip.ReadOnly = true;
            this.textBoxAgeZip.Size = new System.Drawing.Size(193, 22);
            this.textBoxAgeZip.TabIndex = 1;
            this.textBoxAgeZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(8, 231);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(91, 16);
            this.label22.TabIndex = 0;
            this.label22.Text = "Median Age";
            // 
            // groupBox17
            // 
            this.groupBox17.BackColor = System.Drawing.Color.Silver;
            this.groupBox17.Controls.Add(this.textBoxIncomeZip);
            this.groupBox17.Controls.Add(this.textBoxPopZip);
            this.groupBox17.Controls.Add(this.label23);
            this.groupBox17.Controls.Add(this.label25);
            this.groupBox17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox17.Location = new System.Drawing.Point(6, 24);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(306, 113);
            this.groupBox17.TabIndex = 0;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Zipcode Demographics";
            // 
            // textBoxIncomeZip
            // 
            this.textBoxIncomeZip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxIncomeZip.ForeColor = System.Drawing.Color.Black;
            this.textBoxIncomeZip.Location = new System.Drawing.Point(107, 74);
            this.textBoxIncomeZip.Name = "textBoxIncomeZip";
            this.textBoxIncomeZip.ReadOnly = true;
            this.textBoxIncomeZip.Size = new System.Drawing.Size(193, 20);
            this.textBoxIncomeZip.TabIndex = 3;
            this.textBoxIncomeZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxPopZip
            // 
            this.textBoxPopZip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.textBoxPopZip.ForeColor = System.Drawing.Color.Black;
            this.textBoxPopZip.Location = new System.Drawing.Point(107, 28);
            this.textBoxPopZip.Name = "textBoxPopZip";
            this.textBoxPopZip.ReadOnly = true;
            this.textBoxPopZip.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textBoxPopZip.Size = new System.Drawing.Size(193, 20);
            this.textBoxPopZip.TabIndex = 2;
            this.textBoxPopZip.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(6, 75);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(93, 16);
            this.label23.TabIndex = 1;
            this.label23.Text = "Avg. Income";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(6, 29);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(82, 16);
            this.label25.TabIndex = 0;
            this.label25.Text = "Population";
            // 
            // groupBox18
            // 
            this.groupBox18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox18.Controls.Add(this.groupBox7);
            this.groupBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox18.ForeColor = System.Drawing.Color.White;
            this.groupBox18.Location = new System.Drawing.Point(1110, 495);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(363, 477);
            this.groupBox18.TabIndex = 9;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "ZIPCODE";
            // 
            // groupBox19
            // 
            this.groupBox19.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox19.Controls.Add(this.groupBox20);
            this.groupBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox19.ForeColor = System.Drawing.Color.White;
            this.groupBox19.Location = new System.Drawing.Point(740, 495);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(363, 477);
            this.groupBox19.TabIndex = 10;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "CITY";
            // 
            // groupBox20
            // 
            this.groupBox20.BackColor = System.Drawing.Color.Gray;
            this.groupBox20.Controls.Add(this.label26);
            this.groupBox20.Controls.Add(this.listBoxSearchResultsCity);
            this.groupBox20.Controls.Add(this.label27);
            this.groupBox20.Controls.Add(this.label28);
            this.groupBox20.Controls.Add(this.textBoxCity);
            this.groupBox20.Controls.Add(this.textBoxRatingCity);
            this.groupBox20.Controls.Add(this.textBoxReviewsCity);
            this.groupBox20.ForeColor = System.Drawing.Color.White;
            this.groupBox20.Location = new System.Drawing.Point(20, 19);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(327, 444);
            this.groupBox20.TabIndex = 4;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Search Results";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(12, 400);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(84, 16);
            this.label26.TabIndex = 19;
            this.label26.Text = "# of Reviews";
            // 
            // listBoxSearchResultsCity
            // 
            this.listBoxSearchResultsCity.BackColor = System.Drawing.Color.Silver;
            this.listBoxSearchResultsCity.ForeColor = System.Drawing.Color.Black;
            this.listBoxSearchResultsCity.FormattingEnabled = true;
            this.listBoxSearchResultsCity.Location = new System.Drawing.Point(7, 20);
            this.listBoxSearchResultsCity.Name = "listBoxSearchResultsCity";
            this.listBoxSearchResultsCity.ScrollAlwaysVisible = true;
            this.listBoxSearchResultsCity.Size = new System.Drawing.Size(314, 290);
            this.listBoxSearchResultsCity.TabIndex = 0;
            this.listBoxSearchResultsCity.SelectedValueChanged += new System.EventHandler(this.listBoxSearchResultsCity_SelectedValueChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(31, 369);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(47, 16);
            this.label27.TabIndex = 18;
            this.label27.Text = "Rating";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(39, 338);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(30, 16);
            this.label28.TabIndex = 17;
            this.label28.Text = "City";
            this.label28.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxCity
            // 
            this.textBoxCity.BackColor = System.Drawing.Color.Silver;
            this.textBoxCity.ForeColor = System.Drawing.Color.Black;
            this.textBoxCity.Location = new System.Drawing.Point(114, 335);
            this.textBoxCity.Name = "textBoxCity";
            this.textBoxCity.ReadOnly = true;
            this.textBoxCity.Size = new System.Drawing.Size(192, 20);
            this.textBoxCity.TabIndex = 14;
            this.textBoxCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxRatingCity
            // 
            this.textBoxRatingCity.BackColor = System.Drawing.Color.Silver;
            this.textBoxRatingCity.ForeColor = System.Drawing.Color.Black;
            this.textBoxRatingCity.Location = new System.Drawing.Point(114, 366);
            this.textBoxRatingCity.Name = "textBoxRatingCity";
            this.textBoxRatingCity.ReadOnly = true;
            this.textBoxRatingCity.Size = new System.Drawing.Size(192, 20);
            this.textBoxRatingCity.TabIndex = 16;
            this.textBoxRatingCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxReviewsCity
            // 
            this.textBoxReviewsCity.BackColor = System.Drawing.Color.Silver;
            this.textBoxReviewsCity.ForeColor = System.Drawing.Color.Black;
            this.textBoxReviewsCity.Location = new System.Drawing.Point(114, 397);
            this.textBoxReviewsCity.Name = "textBoxReviewsCity";
            this.textBoxReviewsCity.ReadOnly = true;
            this.textBoxReviewsCity.Size = new System.Drawing.Size(192, 20);
            this.textBoxReviewsCity.TabIndex = 15;
            this.textBoxReviewsCity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox21
            // 
            this.groupBox21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox21.Controls.Add(this.groupBox22);
            this.groupBox21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox21.ForeColor = System.Drawing.Color.White;
            this.groupBox21.Location = new System.Drawing.Point(371, 495);
            this.groupBox21.Name = "groupBox21";
            this.groupBox21.Size = new System.Drawing.Size(363, 477);
            this.groupBox21.TabIndex = 10;
            this.groupBox21.TabStop = false;
            this.groupBox21.Text = "STATE";
            // 
            // groupBox22
            // 
            this.groupBox22.BackColor = System.Drawing.Color.Gray;
            this.groupBox22.Controls.Add(this.label29);
            this.groupBox22.Controls.Add(this.listBoxSearchResultsState);
            this.groupBox22.Controls.Add(this.label30);
            this.groupBox22.Controls.Add(this.label31);
            this.groupBox22.Controls.Add(this.textBoxState);
            this.groupBox22.Controls.Add(this.textBoxRatingState);
            this.groupBox22.Controls.Add(this.textBoxReviewsState);
            this.groupBox22.ForeColor = System.Drawing.Color.White;
            this.groupBox22.Location = new System.Drawing.Point(20, 19);
            this.groupBox22.Name = "groupBox22";
            this.groupBox22.Size = new System.Drawing.Size(327, 444);
            this.groupBox22.TabIndex = 4;
            this.groupBox22.TabStop = false;
            this.groupBox22.Text = "Search Results";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(11, 400);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(84, 16);
            this.label29.TabIndex = 19;
            this.label29.Text = "# of Reviews";
            // 
            // listBoxSearchResultsState
            // 
            this.listBoxSearchResultsState.BackColor = System.Drawing.Color.Silver;
            this.listBoxSearchResultsState.ForeColor = System.Drawing.Color.Black;
            this.listBoxSearchResultsState.FormattingEnabled = true;
            this.listBoxSearchResultsState.Location = new System.Drawing.Point(7, 20);
            this.listBoxSearchResultsState.Name = "listBoxSearchResultsState";
            this.listBoxSearchResultsState.ScrollAlwaysVisible = true;
            this.listBoxSearchResultsState.Size = new System.Drawing.Size(314, 290);
            this.listBoxSearchResultsState.TabIndex = 0;
            this.listBoxSearchResultsState.SelectedValueChanged += new System.EventHandler(this.listBoxSearchResultsState_SelectedValueChanged);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(30, 369);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(47, 16);
            this.label30.TabIndex = 18;
            this.label30.Text = "Rating";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.SystemColors.Window;
            this.label31.Location = new System.Drawing.Point(34, 338);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(39, 16);
            this.label31.TabIndex = 17;
            this.label31.Text = "State";
            this.label31.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // textBoxState
            // 
            this.textBoxState.BackColor = System.Drawing.Color.Silver;
            this.textBoxState.ForeColor = System.Drawing.Color.Black;
            this.textBoxState.Location = new System.Drawing.Point(114, 335);
            this.textBoxState.Name = "textBoxState";
            this.textBoxState.ReadOnly = true;
            this.textBoxState.Size = new System.Drawing.Size(192, 20);
            this.textBoxState.TabIndex = 14;
            this.textBoxState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxRatingState
            // 
            this.textBoxRatingState.BackColor = System.Drawing.Color.Silver;
            this.textBoxRatingState.ForeColor = System.Drawing.Color.Black;
            this.textBoxRatingState.Location = new System.Drawing.Point(114, 366);
            this.textBoxRatingState.Name = "textBoxRatingState";
            this.textBoxRatingState.ReadOnly = true;
            this.textBoxRatingState.Size = new System.Drawing.Size(192, 20);
            this.textBoxRatingState.TabIndex = 16;
            this.textBoxRatingState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBoxReviewsState
            // 
            this.textBoxReviewsState.BackColor = System.Drawing.Color.Silver;
            this.textBoxReviewsState.ForeColor = System.Drawing.Color.Black;
            this.textBoxReviewsState.Location = new System.Drawing.Point(114, 397);
            this.textBoxReviewsState.Name = "textBoxReviewsState";
            this.textBoxReviewsState.ReadOnly = true;
            this.textBoxReviewsState.Size = new System.Drawing.Size(192, 20);
            this.textBoxReviewsState.TabIndex = 15;
            this.textBoxReviewsState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(3, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1486, 1006);
            this.tabControl1.TabIndex = 11;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.groupBox21);
            this.tabPage1.Controls.Add(this.groupBox19);
            this.tabPage1.Controls.Add(this.groupBox5);
            this.tabPage1.Controls.Add(this.groupBox18);
            this.tabPage1.Controls.Add(this.groupBox14);
            this.tabPage1.Controls.Add(this.groupBox8);
            this.tabPage1.Controls.Add(this.groupBox10);
            this.tabPage1.Controls.Add(this.groupBox9);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.Control;
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1478, 980);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Business Demographics";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Black;
            this.tabPage2.Controls.Add(this.groupBox31);
            this.tabPage2.Controls.Add(this.groupBox30);
            this.tabPage2.Controls.Add(this.groupBox29);
            this.tabPage2.Controls.Add(this.groupBox6);
            this.tabPage2.Controls.Add(this.groupBox23);
            this.tabPage2.Controls.Add(this.groupBox24);
            this.tabPage2.Controls.Add(this.groupBox26);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1478, 980);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Business Search";
            // 
            // groupBox31
            // 
            this.groupBox31.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox31.Controls.Add(this.reviewGrid);
            this.groupBox31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox31.ForeColor = System.Drawing.Color.White;
            this.groupBox31.Location = new System.Drawing.Point(366, 653);
            this.groupBox31.Name = "groupBox31";
            this.groupBox31.Size = new System.Drawing.Size(747, 322);
            this.groupBox31.TabIndex = 13;
            this.groupBox31.TabStop = false;
            this.groupBox31.Text = "Reviews";
            // 
            // reviewGrid
            // 
            this.reviewGrid.BackgroundColor = System.Drawing.Color.Gray;
            this.reviewGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.reviewGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Stars,
            this.Review});
            this.reviewGrid.Location = new System.Drawing.Point(7, 20);
            this.reviewGrid.Name = "reviewGrid";
            this.reviewGrid.ReadOnly = true;
            this.reviewGrid.Size = new System.Drawing.Size(734, 296);
            this.reviewGrid.TabIndex = 0;
            // 
            // Stars
            // 
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.Stars.DefaultCellStyle = dataGridViewCellStyle1;
            this.Stars.HeaderText = "Stars";
            this.Stars.Name = "Stars";
            this.Stars.ReadOnly = true;
            this.Stars.Width = 50;
            // 
            // Review
            // 
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.Review.DefaultCellStyle = dataGridViewCellStyle2;
            this.Review.HeaderText = "Review";
            this.Review.Name = "Review";
            this.Review.ReadOnly = true;
            this.Review.Width = 635;
            // 
            // groupBox30
            // 
            this.groupBox30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox30.Controls.Add(this.buttonClear);
            this.groupBox30.Controls.Add(this.buttonSearch);
            this.groupBox30.Controls.Add(this.resultsGrid);
            this.groupBox30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox30.ForeColor = System.Drawing.Color.White;
            this.groupBox30.Location = new System.Drawing.Point(366, 113);
            this.groupBox30.Name = "groupBox30";
            this.groupBox30.Size = new System.Drawing.Size(747, 534);
            this.groupBox30.TabIndex = 12;
            this.groupBox30.TabStop = false;
            this.groupBox30.Text = "SEARCH RESULTS";
            // 
            // buttonClear
            // 
            this.buttonClear.BackColor = System.Drawing.Color.Silver;
            this.buttonClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonClear.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonClear.Location = new System.Drawing.Point(378, 498);
            this.buttonClear.Name = "buttonClear";
            this.buttonClear.Size = new System.Drawing.Size(317, 28);
            this.buttonClear.TabIndex = 5;
            this.buttonClear.Text = "CLEAR";
            this.buttonClear.UseVisualStyleBackColor = false;
            this.buttonClear.Click += new System.EventHandler(this.buttonClear_Click);
            // 
            // buttonSearch
            // 
            this.buttonSearch.BackColor = System.Drawing.Color.Silver;
            this.buttonSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonSearch.Location = new System.Drawing.Point(55, 498);
            this.buttonSearch.Name = "buttonSearch";
            this.buttonSearch.Size = new System.Drawing.Size(317, 28);
            this.buttonSearch.TabIndex = 4;
            this.buttonSearch.Text = "SEARCH";
            this.buttonSearch.UseVisualStyleBackColor = false;
            this.buttonSearch.Click += new System.EventHandler(this.buttonSearch_Click);
            // 
            // resultsGrid
            // 
            this.resultsGrid.BackgroundColor = System.Drawing.Color.Gray;
            this.resultsGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultsGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.BusinessName,
            this.City,
            this.State,
            this.Zipcode,
            this.Rating,
            this.NumReviews});
            this.resultsGrid.GridColor = System.Drawing.Color.Silver;
            this.resultsGrid.Location = new System.Drawing.Point(7, 20);
            this.resultsGrid.Name = "resultsGrid";
            this.resultsGrid.ReadOnly = true;
            this.resultsGrid.Size = new System.Drawing.Size(734, 471);
            this.resultsGrid.TabIndex = 0;
            this.resultsGrid.SelectionChanged += new System.EventHandler(this.resultsGrid_SelectionChanged);
            // 
            // groupBox29
            // 
            this.groupBox29.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox29.Controls.Add(this.numericMaxReviews);
            this.groupBox29.Controls.Add(this.numericMinReviews);
            this.groupBox29.Controls.Add(this.numericMaxRating);
            this.groupBox29.Controls.Add(this.numericMinRating);
            this.groupBox29.Controls.Add(this.label38);
            this.groupBox29.Controls.Add(this.label37);
            this.groupBox29.Controls.Add(this.label36);
            this.groupBox29.Controls.Add(this.label35);
            this.groupBox29.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox29.ForeColor = System.Drawing.Color.White;
            this.groupBox29.Location = new System.Drawing.Point(366, 6);
            this.groupBox29.Name = "groupBox29";
            this.groupBox29.Size = new System.Drawing.Size(747, 100);
            this.groupBox29.TabIndex = 11;
            this.groupBox29.TabStop = false;
            this.groupBox29.Text = "Select By Rating";
            // 
            // numericMaxReviews
            // 
            this.numericMaxReviews.BackColor = System.Drawing.Color.Gray;
            this.numericMaxReviews.ForeColor = System.Drawing.Color.White;
            this.numericMaxReviews.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericMaxReviews.Location = new System.Drawing.Point(548, 66);
            this.numericMaxReviews.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericMaxReviews.Name = "numericMaxReviews";
            this.numericMaxReviews.Size = new System.Drawing.Size(120, 20);
            this.numericMaxReviews.TabIndex = 9;
            this.numericMaxReviews.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericMaxReviews.Value = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            // 
            // numericMinReviews
            // 
            this.numericMinReviews.BackColor = System.Drawing.Color.Gray;
            this.numericMinReviews.ForeColor = System.Drawing.Color.White;
            this.numericMinReviews.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericMinReviews.Location = new System.Drawing.Point(548, 31);
            this.numericMinReviews.Maximum = new decimal(new int[] {
            1000000,
            0,
            0,
            0});
            this.numericMinReviews.Name = "numericMinReviews";
            this.numericMinReviews.Size = new System.Drawing.Size(120, 20);
            this.numericMinReviews.TabIndex = 8;
            this.numericMinReviews.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // numericMaxRating
            // 
            this.numericMaxRating.BackColor = System.Drawing.Color.Gray;
            this.numericMaxRating.ForeColor = System.Drawing.Color.White;
            this.numericMaxRating.Location = new System.Drawing.Point(179, 66);
            this.numericMaxRating.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numericMaxRating.Name = "numericMaxRating";
            this.numericMaxRating.Size = new System.Drawing.Size(120, 20);
            this.numericMaxRating.TabIndex = 7;
            this.numericMaxRating.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericMaxRating.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numericMinRating
            // 
            this.numericMinRating.BackColor = System.Drawing.Color.Gray;
            this.numericMinRating.ForeColor = System.Drawing.Color.White;
            this.numericMinRating.Location = new System.Drawing.Point(179, 31);
            this.numericMinRating.Maximum = new decimal(new int[] {
            50,
            0,
            0,
            65536});
            this.numericMinRating.Name = "numericMinRating";
            this.numericMinRating.Size = new System.Drawing.Size(120, 20);
            this.numericMinRating.TabIndex = 6;
            this.numericMinRating.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(360, 66);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(164, 16);
            this.label38.TabIndex = 5;
            this.label38.Text = "Maximum # of Reviews";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(360, 31);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(160, 16);
            this.label37.TabIndex = 4;
            this.label37.Text = "Minimum # of Reviews";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.Location = new System.Drawing.Point(34, 66);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(121, 16);
            this.label36.TabIndex = 3;
            this.label36.Text = "Maximum Rating";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(34, 31);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(117, 16);
            this.label35.TabIndex = 2;
            this.label35.Text = "Minimum Rating";
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox6.Controls.Add(this.groupBox28);
            this.groupBox6.Controls.Add(this.groupBox27);
            this.groupBox6.Controls.Add(this.groupBox25);
            this.groupBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox6.ForeColor = System.Drawing.Color.White;
            this.groupBox6.Location = new System.Drawing.Point(1119, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(356, 971);
            this.groupBox6.TabIndex = 10;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Refine Your Search";
            // 
            // groupBox28
            // 
            this.groupBox28.BackColor = System.Drawing.Color.Gray;
            this.groupBox28.Controls.Add(this.button4);
            this.groupBox28.Controls.Add(this.listBoxSelectedAttributes);
            this.groupBox28.ForeColor = System.Drawing.Color.White;
            this.groupBox28.Location = new System.Drawing.Point(7, 601);
            this.groupBox28.Name = "groupBox28";
            this.groupBox28.Size = new System.Drawing.Size(343, 362);
            this.groupBox28.TabIndex = 10;
            this.groupBox28.TabStop = false;
            this.groupBox28.Text = "Selected Attributes";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Silver;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.button4.Location = new System.Drawing.Point(12, 321);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(317, 28);
            this.button4.TabIndex = 3;
            this.button4.Text = "REMOVE";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // listBoxSelectedAttributes
            // 
            this.listBoxSelectedAttributes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.listBoxSelectedAttributes.ForeColor = System.Drawing.Color.Black;
            this.listBoxSelectedAttributes.FormattingEnabled = true;
            this.listBoxSelectedAttributes.Location = new System.Drawing.Point(6, 19);
            this.listBoxSelectedAttributes.Name = "listBoxSelectedAttributes";
            this.listBoxSelectedAttributes.ScrollAlwaysVisible = true;
            this.listBoxSelectedAttributes.Size = new System.Drawing.Size(331, 290);
            this.listBoxSelectedAttributes.TabIndex = 1;
            // 
            // groupBox27
            // 
            this.groupBox27.BackColor = System.Drawing.Color.Gray;
            this.groupBox27.Controls.Add(this.buttonAddAttribute);
            this.groupBox27.Controls.Add(this.boxValue);
            this.groupBox27.ForeColor = System.Drawing.Color.White;
            this.groupBox27.Location = new System.Drawing.Point(7, 499);
            this.groupBox27.Name = "groupBox27";
            this.groupBox27.Size = new System.Drawing.Size(343, 83);
            this.groupBox27.TabIndex = 9;
            this.groupBox27.TabStop = false;
            this.groupBox27.Text = "Select Value";
            // 
            // buttonAddAttribute
            // 
            this.buttonAddAttribute.BackColor = System.Drawing.Color.Silver;
            this.buttonAddAttribute.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddAttribute.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonAddAttribute.Location = new System.Drawing.Point(13, 46);
            this.buttonAddAttribute.Name = "buttonAddAttribute";
            this.buttonAddAttribute.Size = new System.Drawing.Size(317, 28);
            this.buttonAddAttribute.TabIndex = 2;
            this.buttonAddAttribute.Text = "ADD";
            this.buttonAddAttribute.UseVisualStyleBackColor = false;
            this.buttonAddAttribute.Click += new System.EventHandler(this.buttonAddAttribute_Click);
            // 
            // boxValue
            // 
            this.boxValue.BackColor = System.Drawing.Color.Gray;
            this.boxValue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boxValue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.boxValue.ForeColor = System.Drawing.Color.White;
            this.boxValue.FormattingEnabled = true;
            this.boxValue.Location = new System.Drawing.Point(45, 19);
            this.boxValue.Name = "boxValue";
            this.boxValue.Size = new System.Drawing.Size(249, 21);
            this.boxValue.TabIndex = 4;
            this.boxValue.DropDown += new System.EventHandler(this.boxValue_DropDown);
            // 
            // groupBox25
            // 
            this.groupBox25.BackColor = System.Drawing.Color.Gray;
            this.groupBox25.Controls.Add(this.listBoxAttributes);
            this.groupBox25.ForeColor = System.Drawing.Color.White;
            this.groupBox25.Location = new System.Drawing.Point(6, 31);
            this.groupBox25.Name = "groupBox25";
            this.groupBox25.Size = new System.Drawing.Size(344, 452);
            this.groupBox25.TabIndex = 8;
            this.groupBox25.TabStop = false;
            this.groupBox25.Text = "Select Business Attribute";
            // 
            // listBoxAttributes
            // 
            this.listBoxAttributes.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.listBoxAttributes.ForeColor = System.Drawing.Color.Black;
            this.listBoxAttributes.FormattingEnabled = true;
            this.listBoxAttributes.Location = new System.Drawing.Point(7, 23);
            this.listBoxAttributes.Name = "listBoxAttributes";
            this.listBoxAttributes.ScrollAlwaysVisible = true;
            this.listBoxAttributes.Size = new System.Drawing.Size(331, 407);
            this.listBoxAttributes.TabIndex = 0;
            this.listBoxAttributes.SelectedIndexChanged += new System.EventHandler(this.listBoxAttributes_SelectedIndexChanged);
            // 
            // groupBox23
            // 
            this.groupBox23.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox23.Controls.Add(this.listBoxZipSearch);
            this.groupBox23.Controls.Add(this.listBoxCitySearch);
            this.groupBox23.Controls.Add(this.boxStateSearch);
            this.groupBox23.Controls.Add(this.label32);
            this.groupBox23.Controls.Add(this.label33);
            this.groupBox23.Controls.Add(this.label34);
            this.groupBox23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.groupBox23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox23.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox23.Location = new System.Drawing.Point(3, 6);
            this.groupBox23.Name = "groupBox23";
            this.groupBox23.Size = new System.Drawing.Size(356, 483);
            this.groupBox23.TabIndex = 6;
            this.groupBox23.TabStop = false;
            this.groupBox23.Text = "Select Business Location";
            // 
            // listBoxZipSearch
            // 
            this.listBoxZipSearch.BackColor = System.Drawing.Color.Gray;
            this.listBoxZipSearch.Cursor = System.Windows.Forms.Cursors.Default;
            this.listBoxZipSearch.ForeColor = System.Drawing.Color.White;
            this.listBoxZipSearch.FormattingEnabled = true;
            this.listBoxZipSearch.Location = new System.Drawing.Point(96, 314);
            this.listBoxZipSearch.Name = "listBoxZipSearch";
            this.listBoxZipSearch.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.listBoxZipSearch.ScrollAlwaysVisible = true;
            this.listBoxZipSearch.Size = new System.Drawing.Size(249, 147);
            this.listBoxZipSearch.TabIndex = 4;
            this.listBoxZipSearch.SelectedValueChanged += new System.EventHandler(this.listBoxZipSearch_SelectedValueChanged);
            // 
            // listBoxCitySearch
            // 
            this.listBoxCitySearch.BackColor = System.Drawing.Color.Gray;
            this.listBoxCitySearch.Cursor = System.Windows.Forms.Cursors.Default;
            this.listBoxCitySearch.ForeColor = System.Drawing.Color.White;
            this.listBoxCitySearch.FormattingEnabled = true;
            this.listBoxCitySearch.Location = new System.Drawing.Point(96, 84);
            this.listBoxCitySearch.Name = "listBoxCitySearch";
            this.listBoxCitySearch.ScrollAlwaysVisible = true;
            this.listBoxCitySearch.Size = new System.Drawing.Size(249, 212);
            this.listBoxCitySearch.TabIndex = 2;
            this.listBoxCitySearch.SelectedValueChanged += new System.EventHandler(this.listBoxCitySearch_SelectedValueChanged);
            // 
            // boxStateSearch
            // 
            this.boxStateSearch.BackColor = System.Drawing.Color.Gray;
            this.boxStateSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.boxStateSearch.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.boxStateSearch.ForeColor = System.Drawing.Color.White;
            this.boxStateSearch.FormattingEnabled = true;
            this.boxStateSearch.Location = new System.Drawing.Point(96, 43);
            this.boxStateSearch.Name = "boxStateSearch";
            this.boxStateSearch.Size = new System.Drawing.Size(249, 21);
            this.boxStateSearch.TabIndex = 3;
            this.boxStateSearch.SelectedIndexChanged += new System.EventHandler(this.boxStateSearch_SelectedIndexChanged);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(21, 314);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(65, 16);
            this.label32.TabIndex = 2;
            this.label32.Text = "Zipcode";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(21, 84);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(34, 16);
            this.label33.TabIndex = 1;
            this.label33.Text = "City";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(21, 44);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(44, 16);
            this.label34.TabIndex = 0;
            this.label34.Text = "State";
            // 
            // groupBox24
            // 
            this.groupBox24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox24.Controls.Add(this.buttonAddSearch);
            this.groupBox24.Controls.Add(this.listBoxCategorySearch);
            this.groupBox24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox24.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.groupBox24.Location = new System.Drawing.Point(3, 495);
            this.groupBox24.Name = "groupBox24";
            this.groupBox24.Size = new System.Drawing.Size(356, 254);
            this.groupBox24.TabIndex = 7;
            this.groupBox24.TabStop = false;
            this.groupBox24.Text = "Select Business Category";
            // 
            // buttonAddSearch
            // 
            this.buttonAddSearch.BackColor = System.Drawing.Color.Silver;
            this.buttonAddSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAddSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonAddSearch.Location = new System.Drawing.Point(18, 215);
            this.buttonAddSearch.Name = "buttonAddSearch";
            this.buttonAddSearch.Size = new System.Drawing.Size(317, 28);
            this.buttonAddSearch.TabIndex = 1;
            this.buttonAddSearch.Text = "ADD";
            this.buttonAddSearch.UseVisualStyleBackColor = false;
            this.buttonAddSearch.Click += new System.EventHandler(this.buttonAddSearch_Click);
            // 
            // listBoxCategorySearch
            // 
            this.listBoxCategorySearch.BackColor = System.Drawing.Color.Gray;
            this.listBoxCategorySearch.ForeColor = System.Drawing.Color.White;
            this.listBoxCategorySearch.FormattingEnabled = true;
            this.listBoxCategorySearch.Location = new System.Drawing.Point(7, 19);
            this.listBoxCategorySearch.Name = "listBoxCategorySearch";
            this.listBoxCategorySearch.ScrollAlwaysVisible = true;
            this.listBoxCategorySearch.Size = new System.Drawing.Size(338, 186);
            this.listBoxCategorySearch.TabIndex = 0;
            // 
            // groupBox26
            // 
            this.groupBox26.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.groupBox26.Controls.Add(this.buttonRemoveSearch);
            this.groupBox26.Controls.Add(this.listBoxSelectedCategoriesSearch);
            this.groupBox26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox26.ForeColor = System.Drawing.SystemColors.Control;
            this.groupBox26.Location = new System.Drawing.Point(3, 755);
            this.groupBox26.Name = "groupBox26";
            this.groupBox26.Size = new System.Drawing.Size(356, 222);
            this.groupBox26.TabIndex = 9;
            this.groupBox26.TabStop = false;
            this.groupBox26.Text = "Selected Categories";
            // 
            // buttonRemoveSearch
            // 
            this.buttonRemoveSearch.BackColor = System.Drawing.Color.Silver;
            this.buttonRemoveSearch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonRemoveSearch.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.buttonRemoveSearch.Location = new System.Drawing.Point(18, 186);
            this.buttonRemoveSearch.Name = "buttonRemoveSearch";
            this.buttonRemoveSearch.Size = new System.Drawing.Size(317, 28);
            this.buttonRemoveSearch.TabIndex = 2;
            this.buttonRemoveSearch.Text = "REMOVE";
            this.buttonRemoveSearch.UseVisualStyleBackColor = false;
            this.buttonRemoveSearch.Click += new System.EventHandler(this.buttonRemoveSearch_Click);
            // 
            // listBoxSelectedCategoriesSearch
            // 
            this.listBoxSelectedCategoriesSearch.BackColor = System.Drawing.Color.Gray;
            this.listBoxSelectedCategoriesSearch.ForeColor = System.Drawing.Color.White;
            this.listBoxSelectedCategoriesSearch.FormattingEnabled = true;
            this.listBoxSelectedCategoriesSearch.Location = new System.Drawing.Point(6, 19);
            this.listBoxSelectedCategoriesSearch.Name = "listBoxSelectedCategoriesSearch";
            this.listBoxSelectedCategoriesSearch.ScrollAlwaysVisible = true;
            this.listBoxSelectedCategoriesSearch.Size = new System.Drawing.Size(339, 160);
            this.listBoxSelectedCategoriesSearch.TabIndex = 2;
            // 
            // BusinessName
            // 
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            this.BusinessName.DefaultCellStyle = dataGridViewCellStyle3;
            this.BusinessName.HeaderText = "Business Name";
            this.BusinessName.Name = "BusinessName";
            this.BusinessName.ReadOnly = true;
            this.BusinessName.Width = 180;
            // 
            // City
            // 
            dataGridViewCellStyle4.ForeColor = System.Drawing.Color.Black;
            this.City.DefaultCellStyle = dataGridViewCellStyle4;
            this.City.HeaderText = "City";
            this.City.Name = "City";
            this.City.ReadOnly = true;
            this.City.Width = 110;
            // 
            // State
            // 
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.Black;
            this.State.DefaultCellStyle = dataGridViewCellStyle5;
            this.State.HeaderText = "State";
            this.State.Name = "State";
            this.State.ReadOnly = true;
            // 
            // Zipcode
            // 
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.Black;
            this.Zipcode.DefaultCellStyle = dataGridViewCellStyle6;
            this.Zipcode.HeaderText = "Zipcode";
            this.Zipcode.Name = "Zipcode";
            this.Zipcode.ReadOnly = true;
            // 
            // Rating
            // 
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            this.Rating.DefaultCellStyle = dataGridViewCellStyle7;
            this.Rating.HeaderText = "Average Rating";
            this.Rating.Name = "Rating";
            this.Rating.ReadOnly = true;
            // 
            // NumReviews
            // 
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.Black;
            this.NumReviews.DefaultCellStyle = dataGridViewCellStyle8;
            this.NumReviews.HeaderText = "Number of Reviews";
            this.NumReviews.Name = "NumReviews";
            this.NumReviews.ReadOnly = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1494, 1009);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1600, 1080);
            this.MinimumSize = new System.Drawing.Size(1510, 1048);
            this.Name = "Form1";
            this.Opacity = 0.98D;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Business Analyst";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox21.ResumeLayout(false);
            this.groupBox22.ResumeLayout(false);
            this.groupBox22.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox31.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.reviewGrid)).EndInit();
            this.groupBox30.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.resultsGrid)).EndInit();
            this.groupBox29.ResumeLayout(false);
            this.groupBox29.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericMaxReviews)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinReviews)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMaxRating)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericMinRating)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox28.ResumeLayout(false);
            this.groupBox27.ResumeLayout(false);
            this.groupBox25.ResumeLayout(false);
            this.groupBox23.ResumeLayout(false);
            this.groupBox23.PerformLayout();
            this.groupBox24.ResumeLayout(false);
            this.groupBox26.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox boxStateDem;
        private System.Windows.Forms.Label labelState;
        private System.Windows.Forms.Label labelCity;
        private System.Windows.Forms.Label labelZip;
        private System.Windows.Forms.ListBox listBoxCityDem;
        private System.Windows.Forms.ListBox listBoxZipDem;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.ListBox listBoxCategoryDem;
        private System.Windows.Forms.Button buttonAddCategoryDem;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.ListBox listBoxSelectedCategoriesDem;
        private System.Windows.Forms.Button buttonRemoveCategoryDem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxSearchResultsZip;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxZip;
        private System.Windows.Forms.TextBox textBoxRatingZip;
        private System.Windows.Forms.TextBox textBoxReviewsZip;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox24City;
        private System.Windows.Forms.TextBox textBox44City;
        private System.Windows.Forms.TextBox textBox65City;
        private System.Windows.Forms.TextBox textBox64City;
        private System.Windows.Forms.TextBox textBox18City;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxAgeCity;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.TextBox textBoxIncomeCity;
        private System.Windows.Forms.TextBox textBoxPopCity;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox24Zip;
        private System.Windows.Forms.TextBox textBox44Zip;
        private System.Windows.Forms.TextBox textBox65Zip;
        private System.Windows.Forms.TextBox textBox64Zip;
        private System.Windows.Forms.TextBox textBox18Zip;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBoxAgeZip;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.TextBox textBoxIncomeZip;
        private System.Windows.Forms.TextBox textBoxPopZip;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ListBox listBoxSearchResultsCity;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBoxCity;
        private System.Windows.Forms.TextBox textBoxRatingCity;
        private System.Windows.Forms.TextBox textBoxReviewsCity;
        private System.Windows.Forms.GroupBox groupBox21;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.ListBox listBoxSearchResultsState;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBoxState;
        private System.Windows.Forms.TextBox textBoxRatingState;
        private System.Windows.Forms.TextBox textBoxReviewsState;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label labelPop;
        private System.Windows.Forms.Label labelIncome;
        private System.Windows.Forms.TextBox textBoxPopState;
        private System.Windows.Forms.TextBox textBoxIncomeState;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label labelMedAge;
        private System.Windows.Forms.TextBox textBoxAgeState;
        private System.Windows.Forms.Label labelAge;
        private System.Windows.Forms.Label labelPercent;
        private System.Windows.Forms.TextBox textBox18State;
        private System.Windows.Forms.TextBox textBox64State;
        private System.Windows.Forms.TextBox textBox65State;
        private System.Windows.Forms.TextBox textBox44State;
        private System.Windows.Forms.TextBox textBox24State;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox23;
        private System.Windows.Forms.ListBox listBoxZipSearch;
        private System.Windows.Forms.ListBox listBoxCitySearch;
        private System.Windows.Forms.ComboBox boxStateSearch;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.GroupBox groupBox24;
        private System.Windows.Forms.Button buttonAddSearch;
        private System.Windows.Forms.ListBox listBoxCategorySearch;
        private System.Windows.Forms.GroupBox groupBox25;
        private System.Windows.Forms.ListBox listBoxAttributes;
        private System.Windows.Forms.GroupBox groupBox26;
        private System.Windows.Forms.Button buttonRemoveSearch;
        private System.Windows.Forms.ListBox listBoxSelectedCategoriesSearch;
        private System.Windows.Forms.GroupBox groupBox27;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.ComboBox boxValue;
        private System.Windows.Forms.Button buttonAddAttribute;
        private System.Windows.Forms.GroupBox groupBox28;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.ListBox listBoxSelectedAttributes;
        private System.Windows.Forms.GroupBox groupBox29;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.NumericUpDown numericMaxReviews;
        private System.Windows.Forms.NumericUpDown numericMinReviews;
        private System.Windows.Forms.NumericUpDown numericMaxRating;
        private System.Windows.Forms.NumericUpDown numericMinRating;
        private System.Windows.Forms.GroupBox groupBox30;
        private System.Windows.Forms.DataGridView resultsGrid;
        private System.Windows.Forms.Button buttonClear;
        private System.Windows.Forms.Button buttonSearch;
        private System.Windows.Forms.GroupBox groupBox31;
        private System.Windows.Forms.DataGridView reviewGrid;
        private System.Windows.Forms.DataGridViewTextBoxColumn Review;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stars;
        private System.Windows.Forms.DataGridViewTextBoxColumn NumReviews;
        private System.Windows.Forms.DataGridViewTextBoxColumn Rating;
        private System.Windows.Forms.DataGridViewTextBoxColumn Zipcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn State;
        private System.Windows.Forms.DataGridViewTextBoxColumn City;
        private System.Windows.Forms.DataGridViewTextBoxColumn BusinessName;
    }
}

